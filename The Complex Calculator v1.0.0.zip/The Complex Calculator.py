import math
import random
import time
from math import *
ans = 1
x = 1
y = 1
print("+---------------------------------+\n|  The Complex Calculator v1.0.0  |\n|           by  CMPLX             |\n+---------------------------------+")
def strt():
  global ans
  global y
  global x
  global strtcmd
  print("\n(You can input numbers in scientific notation.)")
  print("\n(Use 'ans' to use your previous answer in a problem, ans will just be 1 by default.)")
  print("\n(You can use 'ans' in a calculation only once, but you can square it or take it to the power of 0.5 to multiply or divide by itself)")
  print("\nOptions:")
  print("\n-add\n-subtract\n-multiply\n-divide\n-power\n-root\n-factorial\n-sin\n-cos\n-tan\n-asin\n-acos\n-atan")
  strtcmd = input("\nWhat would you like to do?> ")
  if strtcmd == "add":
    x = input("Enter your number: ")
    if x == "ans":
      x = ans
      y = input("Enter the number that you want to add to that: ")
      try:
        print("Adding the previous answer and " + str(float(y)) + "...")
      except ValueError:
        print("Sorry, one or both of the inputs were invalid, restarting...")
        time.sleep(3)
        strt()
      n1 = x
      n2 = float(y)
      ans = n1 + n2
      result = str(n1 + n2)
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
    elif y == "ans":
      y = ans
      try:
       print("Adding " + str(float(x)) + " and the previous answer...")
      except ValueError:
        print("Sorry, one or both of those inputs were invalid, restarting...")
        time.sleep(3)
        strt()
      n1 = float(x)
      n2 = y
      ans = n1 + n2
      result = str(n1 + n2)
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
    else:
      y = input("Enter the number that you want to add to that: ")
      try:
        print("Adding " + str(float(x)) + " and " + str(float(y)) + "...")
      except ValueError:
        print("Sorry, one or both of those was an invalid input, restarting...")
        time.sleep(3)
        strt()
      n1 = float(x)
      n2 = float(y)
      ans = n1 + n2
      result = str(n1 + n2)
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
  elif strtcmd == "multiply":
    x = input("Enter your number: ")
    if x == "ans":
      x = ans
      y = input("Enter the number that you want to multiply that by: ")
      try:
        print("Multiplying the previous answer by " + str(float(y)) + "...")
      except ValueError:
        print("Sorry, one or both of the inputs were invalid, restarting...")
        time.sleep(3)
        strt()
      n1 = x
      n2 = float(y)
      ans = n1 * n2
      result = str(n1 * n2)
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
    elif y == "ans":
      y = ans
      try:
       print("Multiplying " + str(float(x)) + " by the previous answer...")
      except ValueError:
        print("Sorry, one or both of those inputs were invalid, restarting...")
        time.sleep(3)
        strt()
      n1 = float(x)
      n2 = y
      ans = n1 * n2
      result = str(n1 * n2)
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
    else:
      y = input("Enter the number that you want to multiply that by: ")
      try:
        print("Multiplying " + str(float(x)) + " by " + str(float(y)) + "...")
      except ValueError:
        print("Sorry, one or both of those was an invalid input, restarting...")
        time.sleep(3)
        strt()
      n1 = float(x)
      n2 = float(y)
      ans = n1 * n2
      result = str(n1 * n2)
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
  elif strtcmd == "subtract":
    x = input("Enter your number: ")
    if x == "ans":
      x = ans
      y = input("Enter the number that you want to subtract from that: ")
      try:
        print("Subtracting " + str(float(y)) + " from the previous answer...")
      except ValueError:
        print("Sorry, one or both of the inputs were invalid, restarting...")
        time.sleep(3)
        strt()
      n1 = x
      n2 = float(y)
      ans = n1 - n2
      result = str(n1 - n2)
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
    elif y == "ans":
      y = ans
      try:
       print("Subtracting the previous answer from " + str(float(x)) + "...")
      except ValueError:
        print("Sorry, one or both of those inputs were invalid, restarting...")
        time.sleep(3)
        strt()
      n1 = float(x)
      n2 = y
      ans = n1 - n2
      result = str(n1 - n2)
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
    else:
      y = input("Enter the number that you want to subtract from that: ")
      try:
        print("Subtracting " + str(float(x)) + " from " + str(float(y)) + "...")
      except ValueError:
        print("Sorry, one or both of those was an invalid input, restarting...")
        time.sleep(3)
        strt()
      n1 = float(x)
      n2 = float(y)
      ans = n1 - n2
      result = str(n1 - n2)
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
  elif strtcmd == "divide":
    x = input("Enter your number: ")
    if x == "ans":
      x = ans
      y = input("Enter the number that you want to divide that by: ")
      try:
        print("Dividing the previous answer by " + str(float(y)) + "...")
      except ValueError:
        print("Sorry, one or both of the inputs were invalid, restarting...")
        time.sleep(3)
        strt()
      n1 = x
      n2 = float(y)
      ans = n1 / n2
      result = str(n1 / n2)
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
    elif y == "ans":
      y = ans
      try:
       print("Dividing " + str(float(x)) + " by the previous answer...")
      except ValueError:
        print("Sorry, one or both of those inputs were invalid, restarting...")
        time.sleep(3)
        strt()
      n1 = float(x)
      n2 = y
      ans = n1 / n2
      result = str(n1 / n2)
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
    else:
      y = input("Enter the number that you want to divide that by: ")
      try:
        print("Dividing " + str(float(x)) + " by " + str(float(y)) + "...")
      except ValueError:
        print("Sorry, one or both of those was an invalid input, restarting...")
        time.sleep(3)
        strt()
      n1 = float(x)
      n2 = float(y)
      ans = n1 / n2
      result = str(n1 / n2)
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
  elif strtcmd == "power":
    x = input("Enter your number: ")
    if x == "ans":
      x = ans
      y = input("Enter your exponent: ")
      try:
        print("Getting the previous answer to the power of " + str(float(y)) + "...")
      except ValueError:
        print("Sorry, one or both of the inputs were invalid, restarting...")
        time.sleep(3)
        strt()
      n1 = x
      n2 = float(y)
      ans = n1 ** n2
      result = str(n1 ** n2)
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
    elif y == "ans":
      y = ans
      try:
       print("Getting " + str(float(x)) + " to the power of the previous answer...")
      except ValueError:
        print("Sorry, one or both of those inputs were invalid, restarting...")
        time.sleep(3)
        strt()
      n1 = float(x)
      n2 = y
      ans = n1 ** n2
      result = str(n1 ** n2)
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
    else:
      y = input("Enter your exponent: ")
      try:
        print("Getting " + str(float(x)) + " to the power of " + str(float(y)) + "...")
      except ValueError:
        print("Sorry, one or both of those was an invalid input, restarting...")
        time.sleep(3)
        strt()
      n1 = float(x)
      n2 = float(y)
      ans = n1 ** n2
      result = str(n1 ** n2)
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
  elif strtcmd == "root":
    x = input("Enter your number: ")
    if x == "ans":
      x = ans
      y = input("Enter the root number: ")
      try:
        print("Getting the \"" + str(ans) + "\" root of " + str(float(y)) + "...")
      except ValueError:
        print("Sorry, one or both of the inputs were invalid, restarting...")
        time.sleep(3)
        strt()
      n1 = x
      n2 = float(y)
      ans = n1 ** (1 / n2)
      result = str(n1 ** (1 / n2))
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
    elif y == "ans":
      y = ans
      try:
       print("Getting the \"" + str(float(x)) + "\" root of the previous answer...")
      except ValueError:
        print("Sorry, one or both of those inputs were invalid, restarting...")
        time.sleep(3)
        strt()
      n1 = float(x)
      n2 = y
      ans = n1 ** (1 / n2)
      result = str(n1 ** (1 / n2))
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
    else:
      y = input("Enter the number that you want to divide that by: ")
      try:
        print("Getting the \"" + str(float(x)) + "\" root of " + str(float(y)) + "...")
      except ValueError:
        print("Sorry, one or both of those was an invalid input, restarting...")
        time.sleep(3)
        strt()
      n1 = float(x)
      n2 = float(y)
      ans = n1 ** (1 / n2)
      result = str(n1 ** (1 / n2))
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
  elif strtcmd == "factorial":
    x = input("Enter the number you want the factorial of: ")
    if x == "ans":
      x = ans
      try:
        print("Getting the factorial of the previous answer...")
      except ValueError:
        print("Sorry, that input was invalid, restarting...")
        time.sleep(3)
        strt()
      n = x
      ans = math.factorial(n)
      result = str(math.factorial(n))
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
    else:
      try:
        print("Getting the factorial of " + str(float(x)) + "...")
      except ValueError:
        print("Sorry, that was an invalid input, restarting...")
        time.sleep(3)
        strt()
      n = float(x)
      ans = math.factorial(n)
      result = str(math.factorial(n))
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
  elif strtcmd == "sin":
    x = input("Enter the number you want the sine of: ")
    if x == "ans":
      x = ans
      try:
        print("Getting the sine of the previous answer...")
      except ValueError:
        print("Sorry, that input was invalid, restarting...")
        time.sleep(3)
        strt()
      n = x
      ans = math.sin(n)
      result = str(math.sin(n))
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
    else:
      try:
        print("Getting the sine of " + str(float(x)) + "...")
      except ValueError:
        print("Sorry, that was an invalid input, restarting...")
        time.sleep(3)
        strt()
      n = float(x)
      ans = math.sin(n)
      result = str(math.sin(n))
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
  elif strtcmd == "cos":
    x = input("Enter the number you want the cosine of: ")
    if x == "ans":
      x = ans
      try:
        print("Getting the cosine of the previous answer...")
      except ValueError:
        print("Sorry, that input was invalid, restarting...")
        time.sleep(3)
        strt()
      n = x
      ans = math.cos(n)
      result = str(math.cos(n))
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
    else:
      try:
        print("Getting the cosine of " + str(float(x)) + "...")
      except ValueError:
        print("Sorry, that was an invalid input, restarting...")
        time.sleep(3)
        strt()
      n = float(x)
      ans = math.cos(n)
      result = str(math.cos(n))
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
  elif strtcmd == "tan":
    x = input("Enter the number you want the tangent of: ")
    if x == "ans":
      x = ans
      try:
        print("Getting the tangent of the previous answer...")
      except ValueError:
        print("Sorry, that input was invalid, restarting...")
        time.sleep(3)
        strt()
      n = x
      ans = math.tan(n)
      result = str(math.tan(n))
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
    else:
      try:
        print("Getting the tangent of " + str(float(x)) + "...")
      except ValueError:
        print("Sorry, that was an invalid input, restarting...")
        time.sleep(3)
        strt()
      n = float(x)
      ans = math.tan(n)
      result = str(math.tan(n))
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
  elif strtcmd == "asin":
    x = input("Enter the number you want the inverse sine of: ")
    if x == "ans":
      x = ans
      try:
        print("Getting the inverse sine of the previous answer...")
      except ValueError:
        print("Sorry, that input was invalid, restarting...")
        time.sleep(3)
        strt()
      n = x
      ans = math.asin(n)
      result = str(math.asin(n))
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
    else:
      try:
        print("Getting the inverse sine of " + str(float(x)) + "...")
      except ValueError:
        print("Sorry, that was an invalid input, restarting...")
        time.sleep(3)
        strt()
      n = float(x)
      ans = math.asin(n)
      result = str(math.asin(n))
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
  elif strtcmd == "acos":
    x = input("Enter the number you want the inverse cosine of: ")
    if x == "ans":
      x = ans
      try:
        print("Getting the inverse cosine of the previous answer...")
      except ValueError:
        print("Sorry, that input was invalid, restarting...")
        time.sleep(3)
        strt()
      n = x
      ans = math.acos(n)
      result = str(math.acos(n))
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
    else:
      try:
        print("Getting the inverse cosine of " + str(float(x)) + "...")
      except ValueError:
        print("Sorry, that was an invalid input, restarting...")
        time.sleep(3)
        strt()
      n = float(x)
      ans = math.acos(n)
      result = str(math.acos(n))
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
  elif strtcmd == "atan":
    x = input("Enter the number you want the inverse tangent of: ")
    if x == "ans":
      x = ans
      try:
        print("Getting the inverse tangent of the previous answer...")
      except ValueError:
        print("Sorry, that input was invalid, restarting...")
        time.sleep(3)
        strt()
      n = x
      ans = math.atan(n)
      result = str(math.atan(n))
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
    else:
      try:
        print("Getting the inverse tangent of " + str(float(x)) + "...")
      except ValueError:
        print("Sorry, that was an invalid input, restarting...")
        time.sleep(3)
        strt()
      n = float(x)
      ans = math.atan(n)
      result = str(math.atan(n))
      time.sleep(1)
      print("Here's the result: " + result)
      input("Input anything to restart: ")
      strt()
  else:
    print("Sorry, I don't know how to \"" + strtcmd + "\", restarting...")
    time.sleep(3)
    strt()
strt()